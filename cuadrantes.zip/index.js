const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bodyParser = require('body-parser');
const cloudinary = require('cloudinary').v2; // Línea 4 - AQUÍ DABA EL ERROR
const app = express();
app.use(express.json({ limit: '50mb' }));

app.use(express.urlencoded({ limit: '50mb', extended: true }));
// Middlewares
app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));
// CLOUDYNARY
cloudinary.config({ 
  cloud_name: 'dplwunlzp', 
  api_key: '515945841913642', 
  api_secret: 'PrB-RTZFI0SaagSEkrIn80ieZiI' 
});

// --- CONFIGURACIÓN DE LA BASE DE DATOS ---
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '', // Cambiado de 'contrasena' a 'password' (es la propiedad de mysql2)
    database: 'back',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});


// --- 1. LOGIN (ACTUALIZADO SEGÚN TU IMAGEN) ---
app.post('/login', async (req, res) => {
    try {
        const { usuario, contrasena } = req.body;
        
        // Unimos usuarios_sistema con la tabla persona para obtener el nombre real
        const sql = `
            SELECT 
                u.id_usuario as id, 
                u.usuario, 
                p.nombres, 
                p.apellido_paterno, 
                p.apellido_materno,
                r.nombre_rol as rol
            FROM usuarios_sistema u
            INNER JOIN persona p ON u.id_persona = p.id_persona
            LEFT JOIN sistema_roles r ON u.id_rol = r.id_rol
            WHERE u.usuario = ? AND u.contrasena = ? AND u.acceso_habilitado = 1
        `;

        const [results] = await db.query(sql, [usuario, contrasena]);

        if (results.length > 0) {
            // Ahora enviamos el objeto completo con nombres y apellidos
            res.json(results[0]);
        } else {
            res.status(401).json({ message: "Credenciales incorrectas o acceso deshabilitado" });
        }
    } catch (err) {
        console.error("❌ Error en Login:", err);
        res.status(500).json({ message: "Error interno", error: err.message });
    }
});
// --- 3. REPORTAR para ingresr a ocurre_registro  ---
// 1. LISTAR (Con url_imagen corregido)
app.get('/ocurrencias', async (req, res) => {
    try {
        const sql = `
            SELECT o.id_ocurrencia AS id, o.descripcion, o.fecha_reporte AS fecha, o.referencia AS lugar,
                   m.nombre AS modalidad, f.foto AS url_foto,
                   CONCAT(p.nombres, ' ', p.apellido_paterno) AS registrado_por
            FROM ocurrencia_registro o
            LEFT JOIN cat_modalidad m ON o.id_modalidad = m.id
            LEFT JOIN usuarios_sistema u ON o.id_usuario = u.id_usuario
            LEFT JOIN persona p ON u.id_persona = p.id_persona
            LEFT JOIN (SELECT id_ocurrencia, MIN(url_imagen) as foto FROM foto_ocurrencia_registro GROUP BY id_ocurrencia) f 
            ON o.id_ocurrencia = f.id_ocurrencia
            ORDER BY o.fecha_reporte DESC`;
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// 2. INSERTAR (Validando FKs obligatorios)
app.post('/reportar-nuevo', async (req, res) => {
    const { id_usuario, id_modalidad, descripcion, direccion, latitud, longitud, foto } = req.body;

    try {
        // 1. Guardar la ocurrencia (id_tipo_ocurrencia es 1 por defecto según tu SQL)
        const sqlOcurrencia = `INSERT INTO ocurrencia_registro (
    id_tipo_ocurrencia, descripcion, hora_alerta, hora_llegada, 
    hora_repliegue, id_lugar, id_usuario, id_modalidad, 
    latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
    unidad_encargada, fecha_reporte, fecha_evento, estado, grupo, id_origen
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?)`;
      const [result] = await connection.query(sqlOcurrencia, [
    id_tipo_ocurrencia, descripcion, hora_alerta, hora_llegada, 
    hora_repliegue, id_lugar, id_usuario, id_modalidad, 
    latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
    unidad_encargada, 
    fecha_evento, // El campo que agregamos para ayer/hoy
    estado || 1, 
    grupo, 
    id_origen // Este es el que causaba el error 500
]);
        const id_nueva_ocurrencia = result.insertId;

        // 2. Guardar la foto vinculada
        if (foto && id_nueva_ocurrencia) {
            const sqlFoto = `INSERT INTO foto_ocurrencia_registro (id_ocurrencia, url_imagen, fecha_subida) VALUES (?, ?, NOW())`;
            await db.query(sqlFoto, [id_nueva_ocurrencia, foto]);
        }

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, error: err.message });
    }
});
// 3. ELIMINAR
app.delete('/ocurrencia/:id', async (req, res) => {
    try {
        await db.query("DELETE FROM foto_ocurrencia_registro WHERE id_ocurrencia = ?", [req.params.id]);
        await db.query("DELETE FROM ocurrencia_registro WHERE id_ocurrencia = ?", [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- 2. REPORTAR el primerop ---
app.post('/reportar', async (req, res) => {
    try {
        const { 
            usuario_id, modalidad_id, descripcion, fotos, 
            latitud, longitud, area, lugar 
        } = req.body;

        const sql1 = `INSERT INTO ocurrencias 
                      (usuario_id, modalidad_id, descripcion, latitud, longitud, area, lugar, fecha) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`;
        
        const [resultOcc] = await db.query(sql1, [
            usuario_id, modalidad_id, descripcion, 
            latitud || 0, longitud || 0, area || 'App', 
            lugar || 'Ubicación detectada'
        ]);

        const ocurrenciaId = resultOcc.insertId;

        if (fotos && Array.isArray(fotos) && fotos.length > 0) {
            const values = fotos.map(url => [ocurrenciaId, url]);
            // Importante: mysql2 usa esta sintaxis para inserts múltiples
            await db.query("INSERT INTO fotos_ocurrencia (ocurrencia_id, url_foto) VALUES ?", [values]);
        }

        res.json({ success: true, id: ocurrenciaId });
    } catch (err) {
        console.error("❌ Error en reporte:", err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// --- 3. CATEGORÍAS ---
app.get('/categorias-full', async (req, res) => {
    try {
        const query = `
            SELECT 
                g.id AS gen_id, g.nombre AS gen_nombre, 
                e.id AS esp_id, e.nombre AS esp_nombre, 
                m.id AS mod_id, m.nombre AS mod_nombre 
            FROM cat_generica g 
            LEFT JOIN cat_especifica e ON g.id = e.generica_id 
            LEFT JOIN cat_modalidad m ON e.id = m.especifica_id 
            ORDER BY g.nombre, e.nombre, m.nombre`;
            
        const [results] = await db.query(query);
        res.json(results);
    } catch (err) {
        console.error("❌ Error en categorías:", err);
        res.status(500).json([]);
    }
});

// --- 4. LISTAR REPORTES ---
app.get('/reportes', async (req, res) => {
    try {
        const { usuario_id } = req.query;
        let query = `
            SELECT 
                o.*, 
                m.nombre as nombre_modalidad,
                GROUP_CONCAT(f.url_foto) as lista_fotos
            FROM ocurrencias o
            LEFT JOIN cat_modalidad m ON o.modalidad_id = m.id
            LEFT JOIN fotos_ocurrencia f ON o.id = f.ocurrencia_id
        `;

        const params = [];
        if (usuario_id) {
            query += " WHERE o.usuario_id = ?";
            params.push(usuario_id);
        }

        query += " GROUP BY o.id ORDER BY o.fecha DESC";

        const [results] = await db.query(query, params);

        const procesados = results.map(row => ({
            ...row,
            fotos: row.lista_fotos ? row.lista_fotos.split(',') : []
        }));

        res.json(procesados);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- actualizar ---
app.post('/actualizar-turno', async (req, res) => {
    try {
        const { id_persona, fecha, sigla_turno } = req.body;

        // 1. Buscamos el ID del turno (ej: 'M' -> id 1)
        const [turnos] = await db.query('SELECT id FROM turno WHERE sigla = ?', [sigla_turno]);
        
        if (turnos.length === 0) {
            return res.status(400).json({ success: false, message: "Turno inválido" });
        }

        const id_turno = turnos[0].id;

        // 2. Insertamos o actualizamos (Esto activa tu trigger de auditoría)
        const sql = `
            INSERT INTO jornada_laboral (id_persona, id_turno, fecha_dia)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE id_turno = VALUES(id_turno)
        `;
        
        await db.query(sql, [id_persona, id_turno, fecha]);

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});


// --- 5. CRUD PERSONA ---

// A. Obtener todas las personas (Listar)
app.get('/personas', async (req, res) => {
    try {
        const sql = `
            SELECT 
                id_persona, nombres, apellido_paterno, apellido_materno, 
                documento_numero, cargo_operativo, estado_laboral 
            FROM persona 
            ORDER BY apellido_paterno ASC
        `;
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        console.error("❌ Error al obtener personas:", err);
        res.status(500).json({ message: "Error al obtener datos" });
    }
});

// B. Insertar nueva persona
app.post('/personas', async (req, res) => {
    try {
        const { 
            nombres, apellido_paterno, apellido_materno, 
            documento_numero, cargo_operativo 
        } = req.body;

        const sql = `
            INSERT INTO persona 
            (nombres, apellido_paterno, apellido_materno, documento_numero, cargo_operativo, estado_laboral) 
            VALUES (?, ?, ?, ?, ?, 'ACTIVO')
        `;
        
        const [result] = await db.query(sql, [
            nombres, apellido_paterno, apellido_materno, 
            documento_numero, cargo_operativo
        ]);

        res.json({ success: true, id: result.insertId });
    } catch (err) {
        console.error("❌ Error al insertar persona:", err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// C. Actualizar estado (Para el componente Switch / Slicer)
app.patch('/personas/:id/estado', async (req, res) => {
    try {
        const { id } = req.params;
        const { estado_laboral } = req.body; // 'ACTIVO' o 'INACTIVO'

        const sql = `UPDATE persona SET estado_laboral = ? WHERE id_persona = ?`;
        await db.query(sql, [estado_laboral, id]);

        res.json({ success: true, message: "Estado actualizado" });
    } catch (err) {
        console.error("❌ Error al cambiar estado:", err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// D. Editar persona (General)
app.put('/personas/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nombres, apellido_paterno, documento_numero, cargo_operativo } = req.body;

        const sql = `
            UPDATE persona 
            SET nombres = ?, apellido_paterno = ?, documento_numero = ?, cargo_operativo = ? 
            WHERE id_persona = ?
        `;
        await db.query(sql, [nombres, apellido_paterno, documento_numero, cargo_operativo, id]);

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// E. Eliminar persona
app.delete('/personas/:id', async (req, res) => {
    try {
        const { id } = req.params;
        // Nota: Si la persona tiene llaves foráneas en otras tablas (ej. jornada_laboral),
        // podrías necesitar un borrado lógico o manejar la restricción.
        await db.query('DELETE FROM persona WHERE id_persona = ?', [id]);
        res.json({ success: true });
    } catch (err) {
        console.error("❌ Error al eliminar:", err);
        res.status(500).json({ success: false, message: "No se puede eliminar: tiene registros asociados" });
    }
});

// --- RUTA PARA EL MAPA Y LA TABLA ---
// --- RUTA ACTUALIZADA PARA EL MAPA Y LA TABLA ---
app.get('/ocurrencias', async (req, res) => {
    try {
        const sql = `
            SELECT 
                o.id, 
                o.descripcion, 
                o.fecha, 
                o.latitud, 
                o.longitud, 
                o.lugar,
                m.nombre AS modalidad,
              
                CONCAT(p.nombres, ' ', p.apellido_paterno) AS registrado_por
            FROM ocurrencias o
            LEFT JOIN cat_modalidad m ON o.modalidad_id = m.id
            LEFT JOIN usuarios_sistema u ON o.usuario_id = u.id_usuario
            LEFT JOIN persona p ON u.id_persona = p.id_persona
           
            ORDER BY o.fecha DESC
        `;
        const [results] = await db.query(sql);
        res.json(results); // Aquí enviamos el Array de resultados
    } catch (err) {
        console.error("ERROR EN SQL:", err.message);
        // IMPORTANTE: Devolvemos un array vacío para que el frontend no explote
        res.status(500).json([]); 
    }
});
// Ejemplo en tu API http://192.168.1.61:3000/poligonos-jv
app.get('/importar-geometria', async (req, res) => {
    try {
        const fs = require('fs');
        const data = JSON.parse(fs.readFileSync('./jv.json', 'utf8'));

        await db.query("TRUNCATE TABLE jv_poligono_gis");

        for (const feature of data.features) {
            const nombre = feature.properties.name;
            const coords = feature.geometry.coordinates[0];

            // Creamos el texto WKT invirtiendo el orden: -12 primero, luego espacio, luego -77
            // Resultado esperado: "POLYGON((-12.07 -77.04, -12.08 -77.05...))"
            const wktPoints = coords.map(p => `${p[1]} ${p[0]}`).join(',');
            const wkt = `POLYGON((${wktPoints}))`;

            // Insertamos usando ST_GeomFromText
            await db.query(
                "INSERT INTO jv_poligono_gis (nombre_cuadrante, area_poligono) VALUES (?, ST_GeomFromText(?))",
                [nombre, wkt]
            );
        }
        res.send("<h1>¡ORDEN FORZADO COMPLETADO!</h1>");
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//aopp esto es para mostrar
app.get('/poligonos-jv', async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT 
                nombre_cuadrante as nombre, 
                ST_AsGeoJSON(area_poligono, 6, 2) as geometria 
            FROM jv_poligono_gis
        `);

        const resultado = rows.map(fila => {
            let geoFinal;
            
            // Si ya es un objeto, lo usamos directo. Si es string, lo parseamos.
            if (typeof fila.geometria === 'object' && fila.geometria !== null) {
                geoFinal = fila.geometria;
            } else {
                try {
                    geoFinal = JSON.parse(fila.geometria);
                } catch (e) {
                    geoFinal = null; // O un polígono vacío por defecto
                }
            }

            return {
                nombre: fila.nombre,
                geometria: geoFinal
            };
        });

        res.json(resultado);
    } catch (error) {
        console.error("Error al obtener polígonos:", error);
        res.status(500).json({ error: error.message });
    }
});


//para importar http://localhost:3000/importar-geometria-pnp
app.get('/importar-geometria-pnp', async (req, res) => {
    try {
        const fs = require('fs');
        // Asegúrate de que este sea el JSON con los cuadrantes de la PNP
        const data = JSON.parse(fs.readFileSync('./cuadrantes.json', 'utf8'));

        // Limpiamos la tabla PNP antes de cargar
        await db.query("TRUNCATE TABLE pnp_poligono_gis");

        for (const feature of data.features) {
            const nombre = feature.properties.name || "Sin nombre";
            const coords = feature.geometry.coordinates[0];

            // Inversión para Lima: Latitud (-12) primero para el WKT
            const wktPoints = coords.map(p => `${p[1]} ${p[0]}`).join(',');
            const wkt = `POLYGON((${wktPoints}))`;

            await db.query(
                "INSERT INTO pnp_poligono_gis (nombre_cuadrante, area_poligono) VALUES (?, ST_GeomFromText(?))",
                [nombre, wkt]
            );
        }
        res.send("<h1>¡Datos de PNP cargados exitosamente!</h1>");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en carga PNP: " + error.message);
    }
});

//mostrar pnmp  http://192.168.1.61:3000/poligonos-pnp
app.get('/poligonos-pnp', async (req, res) => {
    try {
        // Consultamos a la tabla pnp_poligono_gis
        const [rows] = await db.query(`
            SELECT 
                nombre_cuadrante as nombre, 
                ST_AsGeoJSON(area_poligono, 6, 2) as geometria 
            FROM pnp_poligono_gis
        `);

        const resultado = rows.map(fila => {
            let geoFinal;
            
            // Validación de seguridad para el formato de geometría
            if (typeof fila.geometria === 'object' && fila.geometria !== null) {
                geoFinal = fila.geometria;
            } else {
                try {
                    geoFinal = JSON.parse(fila.geometria);
                } catch (e) {
                    geoFinal = null;
                }
            }

            return {
                nombre: fila.nombre,
                geometria: geoFinal
            };
        });

        res.json(resultado);
    } catch (error) {
        console.error("Error al obtener polígonos PNP:", error);
        res.status(500).json({ error: error.message });
    }
});

//ESTO ES PARA VER UNIFICADO

app.get('/poligonos', async (req, res) => {
    const { tipo } = req.query;
    try {
        let consultas = [];
        
        // Configuramos qué tablas consultar
        if (tipo === 'jv' || tipo === 'ambos') {
            consultas.push(`SELECT nombre_cuadrante as nombre, ST_AsGeoJSON(area_poligono, 6, 2) as geometria, 'jv' as fuente FROM jv_poligono_gis`);
        }
        if (tipo === 'pnp' || tipo === 'ambos') {
            consultas.push(`SELECT nombre_cuadrante as nombre, ST_AsGeoJSON(area_poligono, 6, 2) as geometria, 'pnp' as fuente FROM pnp_poligono_gis`);
        }

        const queryFinal = consultas.join(' UNION ALL ');
        const [rows] = await db.query(queryFinal);

        const resultado = rows.map(fila => ({
            nombre: fila.nombre,
            fuente: fila.fuente,
            geometria: typeof fila.geometria === 'string' ? JSON.parse(fila.geometria) : fila.geometria
        }));

        res.json(resultado);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


// --- para listar---

// server.js
// En tu server.js

// LISTAR PROVINCIAS (Con el nombre del departamento)
app.get('/provincias', async (req, res) => {
    try {
        const sql = `
            SELECT p.*, d.nombre_departamento 
            FROM provincia p 
            INNER JOIN departamento d ON p.id_departamento = d.id_departamento 
            WHERE p.estado = 1 
            ORDER BY p.id_provincia DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// LISTAR DEPARTAMENTOS (Para el Picker)
app.get('/departamentos', async (req, res) => {
    try {
        const [rows] = await db.query("SELECT id_departamento, nombre_departamento FROM departamento WHERE estado = 1");
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// INSERTAR PROVINCIA
app.post('/provincias', async (req, res) => {
    try {
        const { nombre_provincia, id_departamento } = req.body;
        const sql = "INSERT INTO provincia (nombre_provincia, id_departamento, estado) VALUES (?, ?, 1)";
        await db.query(sql, [nombre_provincia, id_departamento]);
        res.json({ success: true, message: "Provincia creada" });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// INSERTAR O ACTUALIZAR PROVINCIA
app.post('/provincias', async (req, res) => {
    try {
        const { nombre_provincia, id_departamento, id_provincia } = req.body;
        const nombre = nombre_provincia.toUpperCase().trim();

        if (id_provincia) {
            // EDITAR
            await db.query("UPDATE provincia SET nombre_provincia = ?, id_departamento = ? WHERE id_provincia = ?", 
            [nombre, id_departamento, id_provincia]);
        } else {
            // NUEVO
            await db.query("INSERT INTO provincia (nombre_provincia, id_departamento, estado) VALUES (?, ?, 1)", 
            [nombre, id_departamento]);
        }
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// DESACTIVAR PROVINCIA (Borrado Lógico)
app.patch('/provincias/:id/desactivar', async (req, res) => {
    try {
        await db.query("UPDATE provincia SET estado = 0 WHERE id_provincia = ?", [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false });
    }
});
// --- CRUD DISTRITO CON JERARQUÍA Y MODALES ---
// LISTAR DISTRITOS (Con Provincia y Departamento)
app.get('/distritos', async (req, res) => {
    try {
        const sql = `
            SELECT d.*, p.nombre_provincia, dep.nombre_departamento, dep.id_departamento
            FROM distrito d
            INNER JOIN provincia p ON d.id_provincia = p.id_provincia
            INNER JOIN departamento dep ON p.id_departamento = dep.id_departamento
            WHERE d.estado = 1 
            ORDER BY d.id_distrito DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// LISTAR PROVINCIAS POR DEPARTAMENTO (Para el filtro en cascada)
app.get('/provincias/filtro/:id_dep', async (req, res) => {
    try {
        const { id_dep } = req.params;
        const [rows] = await db.query(
            "SELECT id_provincia, nombre_provincia FROM provincia WHERE id_departamento = ? AND estado = 1", 
            [id_dep]
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// INSERTAR DISTRITO
app.post('/distritos', async (req, res) => {
    try {
        const { nombre_distrito, id_provincia } = req.body;
        const sql = "INSERT INTO distrito (nombre_distrito, id_provincia, estado) VALUES (?, ?, 1)";
        await db.query(sql, [nombre_distrito, id_provincia]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});
// EDITAR DISTRITO
app.put('/distritos/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre_distrito, id_provincia } = req.body;
        const sql = "UPDATE distrito SET nombre_distrito = ?, id_provincia = ? WHERE id_distrito = ?";
        await db.query(sql, [nombre_distrito.toUpperCase(), id_provincia, id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// BORRADO LÓGICO (DESACTIVAR)
app.patch('/distritos/:id/desactivar', async (req, res) => {
    try {
        const { id } = req.params;
        await db.query("UPDATE distrito SET estado = 0 WHERE id_distrito = ?", [id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false });
    }
});
// --- CRUD DEPARTAMENTO ---

// A. Listar departamentos activos
app.get('/departamentos', async (req, res) => {
    try {
        const sql = "SELECT id_departamento, nombre_departamento FROM departamento WHERE estado = 1 ORDER BY nombre_departamento ASC";
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: "Error al obtener departamentos" });
    }
});

// B. Insertar Departamento con VALIDACIÓN de duplicados
app.post('/departamentos', async (req, res) => {
    try {
        const { nombre_departamento } = req.body;

        if (!nombre_departamento) {
            return res.status(400).json({ success: false, message: "El nombre es obligatorio" });
        }

        // 1. Validar si ya existe (sin importar mayúsculas/minúsculas)
        const [existentes] = await db.query(
            "SELECT id_departamento FROM departamento WHERE nombre_departamento = ? AND estado = 1", 
            [nombre_departamento.trim().toUpperCase()]
        );

        if (existentes.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: "Este departamento ya existe en la base de datos." 
            });
        }

        // 2. Insertar si no es duplicado
        const sql = "INSERT INTO departamento (nombre_departamento, estado) VALUES (?, 1)";
        const [result] = await db.query(sql, [nombre_departamento.trim().toUpperCase()]);
        
        res.json({ success: true, id: result.insertId });

    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// C. Actualizar Departamento
app.put('/departamentos/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre_departamento } = req.body;

        // Validar que el nuevo nombre no lo tenga otro registro
        const [duplicado] = await db.query(
            "SELECT id_departamento FROM departamento WHERE nombre_departamento = ? AND id_departamento != ? AND estado = 1", 
            [nombre_departamento, id]
        );

        if (duplicado.length > 0) {
            return res.status(400).json({ success: false, message: "El nombre ya está en uso por otro departamento." });
        }

        const sql = "UPDATE departamento SET nombre_departamento = ? WHERE id_departamento = ?";
        await db.query(sql, [nombre_departamento.toUpperCase(), id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// D. Borrado Lógico (Cambiar estado)
app.delete('/departamentos/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        // OPCIONAL: Validar si tiene provincias asociadas antes de "eliminar"
        const [provincias] = await db.query("SELECT id_provincia FROM provincia WHERE id_departamento = ? AND estado = 1", [id]);
        if (provincias.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: "No se puede desactivar: tiene provincias asociadas." 
            });
        }

        const sql = "UPDATE departamento SET estado = 0 WHERE id_departamento = ?";
        await db.query(sql, [id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});
// --- RUTA 1: LISTAR TODAS LAS VÍAS (Con JOIN a tipos y distritos) ---
app.get('/vias', async (req, res) => {
    try {
        const sql = `
            SELECT 
                v.id_via, 
                v.nombre_via, 
                v.id_tipo_via, 
                v.id_distrito, 
                t.abreviatura,  -- Campo real en tu SQL
                t.descripcion,  -- Campo real en tu SQL
                d.nombre_distrito
            FROM via v
            INNER JOIN tipo_via t ON v.id_tipo_via = t.id_tipo_via
            INNER JOIN distrito d ON v.id_distrito = d.id_distrito
            WHERE v.estado = 1
            ORDER BY v.id_via DESC
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        console.error("Error en GET /vias:", err);
        res.status(500).json({ error: err.message });
    }
});

// --- RUTA 2: LISTAR TIPOS DE VÍA (Para el Picker) ---
app.get('/tipos-via', async (req, res) => {
    try {
        // Seleccionamos abreviatura y descripcion según tu tabla
        const sql = "SELECT id_tipo_via, abreviatura, descripcion FROM tipo_via WHERE estado = 1";
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        console.error("Error en GET /tipos-via:", err);
        res.status(500).json({ error: err.message });
    }
});

// --- RUTA 3: LISTAR DISTRITOS (Para el Picker) ---
app.get('/distritos/todos', async (req, res) => {
    try {
        const sql = "SELECT id_distrito, nombre_distrito FROM distrito WHERE estado = 1 ORDER BY nombre_distrito ASC";
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- RUTA 4: CREAR NUEVA VÍA ---
app.post('/vias', async (req, res) => {
    try {
        const { nombre_via, id_tipo_via, id_distrito } = req.body;
        const sql = "INSERT INTO via (id_tipo_via, nombre_via, id_distrito, estado) VALUES (?, ?, ?, 1)";
        const [result] = await db.query(sql, [id_tipo_via, nombre_via.toUpperCase(), id_distrito]);
        res.json({ success: true, id: result.insertId });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// --- RUTA 5: ACTUALIZAR VÍA EXISTENTE ---
app.put('/vias/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre_via, id_tipo_via, id_distrito } = req.body;
        const sql = "UPDATE via SET id_tipo_via = ?, nombre_via = ?, id_distrito = ? WHERE id_via = ?";
        await db.query(sql, [id_tipo_via, nombre_via.toUpperCase(), id_distrito, id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// --- RUTA 6: DESACTIVAR VÍA (Borrado Lógico) ---
app.patch('/vias/:id/desactivar', async (req, res) => {
    try {
        const { id } = req.params;
        const sql = "UPDATE via SET estado = 0 WHERE id_via = ?";
        await db.query(sql, [id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ==========================================
// 1. LISTADOS PARA LOS PICKERS (TODOS)
// ==========================================
// Esto evita que el server se caiga si una tabla no existe
const consultarTabla = async (sql, res) => {
    try {
        const [rows] = await db.query(sql);
        res.json(rows || []);
    } catch (err) {
        console.error("Error en query:", sql, err.message);
        res.status(500).json({ error: "Error en la base de datos", detalle: err.message });
    }
};


// --- LISTADO DE PICKERS ---
app.get('/vias', (req, res) => {
    consultarTabla("SELECT id_via, nombre_via FROM via WHERE estado = 1 ORDER BY nombre_via ASC", res);
});

app.get('/cuadras', (req, res) => {
    consultarTabla("SELECT id_cuadra, numero_cuadra FROM cuadra ORDER BY numero_cuadra ASC", res);
});

app.get('/jv-cuadrantes', (req, res) => {
    consultarTabla("SELECT id_jv_cuadrante, nombre_cuadrante FROM jv_cuadrante ORDER BY nombre_cuadrante ASC", res);
});

// Ruta para Sector PNP (Asegúrate que la tabla sea pnp_cuadrante)
app.get('/pnp-cuadrantes', async (req, res) => {
    try {
        const [rows] = await db.query("SELECT id_pnp_cuadrante, codigo_cuadrante FROM pnp_cuadrante ORDER BY codigo_cuadrante ASC");
        res.json(rows);
    } catch (err) {
        console.error("Error en PNP:", err.message);
        res.status(500).json({ error: "Fallo en tabla pnp_cuadrante" });
    }
});

app.get('/tipos-lugar', async (req, res) => {
    try {
        // Filtramos por estado = 1 para que el Picker solo jale los activos
        const [rows] = await db.query("SELECT id_tipo, nombre_tipo FROM tipos_lugar WHERE estado = 1 ORDER BY nombre_tipo ASC");
        res.json(rows);
    } catch (err) {
        console.error("Error en Tipo Lugar:", err.message);
        res.status(500).json({ error: "Fallo al obtener tipos" });
    }
});
// ==========================================
// 2. CRUD DE LUGARES (CON TODOS LOS FK)
// ==========================================
// Listar Lugares con nombres de fecha_eventos
// Listar lugares activos
app.post('/lugares', async (req, res) => {
    // 1. Recibimos los datos del celular
    const { 
        nombre_lugar, 
        direccion, 
        id_via, 
        id_cuadra, 
        id_tipo_lugar, 
        id_jv_cuadrante, 
        id_pnp_cuadrante, 
        latitud, 
        longitud 
    } = req.body;

    console.log("Datos recibidos para insertar:", req.body);

    try {
        // 2. Creamos el punto WKT para la columna posicion_gps (Obligatorio)
        // Usamos lat/lon o 0,0 si vienen vacíos
        const lat = latitud || 0;
        const lon = longitud || 0;
        const puntoWKT = `POINT(${lat} ${lon})`;

        // 3. SQL: Insertamos en las columnas base. 
        // El trigger se encargará de las que terminan en _asig.
        const sql = `INSERT INTO lugar 
            (nombre_lugar, direccion, id_via, id_cuadra, id_tipo_lugar, 
             id_pnp_cuadrante, id_jv_cuadrante, 
             latitud, longitud, posicion_gps) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ST_GeomFromText(?))`;
        
        const [result] = await db.query(sql, [
            nombre_lugar ? nombre_lugar.toUpperCase() : "SIN NOMBRE", 
            direccion || 'SIN DIRECCIÓN', 
            id_via || null, 
            id_cuadra || null, 
            id_tipo_lugar || null, 
            id_pnp_cuadrante || null, 
            id_jv_cuadrante || null,  
            latitud || null,
            longitud || null,
            puntoWKT
        ]);

        res.json({ success: true, id: result.insertId });

    } catch (err) {
        console.error("ERROR SQL AL GUARDAR:", err.sqlMessage);
        res.status(500).json({ error: err.sqlMessage || "Error al insertar en la base de datos" });
    }
});
app.get('/lugares', async (req, res) => {
    try {
        // Consultamos solo la tabla lugar para evitar el error de "Table doesn't exist"
        const sql = `SELECT id_lugar, nombre_lugar, direccion, id_via, id_tipo_lugar, estado FROM lugar ORDER BY id_lugar DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        console.error("Error SQL:", err.message);
        res.status(500).json({ error: err.message });
    }
});

// RUTA PARA EL SLICER (Switch)
app.patch('/lugares/:id/estado', async (req, res) => {
    const { id } = req.params;
    const { estado } = req.body;
    try {
        await db.query('UPDATE lugar SET estado = ? WHERE id_lugar = ?', [estado, id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.get('/lugares-giss', async (req, res) => {
    try {
        const sql = `
            SELECT 
                L.id_lugar, 
                L.nombre_lugar, 
                V.nombre_via, 
                L.latitud, 
                L.longitud,
                T.nombre_tipo as tipo,
                P.codigo_cuadrante as nom_pnp, 
                J.nombre_cuadrante as nom_jv
            FROM lugar L
            LEFT JOIN via V ON L.id_via = V.id_via
            LEFT JOIN tipos_lugar T ON L.id_tipo_lugar = T.id_tipo
            LEFT JOIN pnp_cuadrante P ON L.id_pnp_cuadrante = P.id_pnp_cuadrante
            LEFT JOIN jv_cuadrante J ON L.id_jv_cuadrante = J.id_jv_cuadrante
            WHERE L.estado = 1
        `;
        const [rows] = await db.query(sql);
        
        const resultado = rows.map(f => ({
            id: f.id_lugar,
            nombre: f.nombre_lugar,
            direccion: f.nombre_via || '',
            tipo: f.tipo || 'GENERAL',
            pnp: f.nom_pnp || 'N/A', // Para filtrar en el TSX
            jv: f.nom_jv || 'N/A',   // Para filtrar en el TSX
            coords: [parseFloat(f.latitud), parseFloat(f.longitud)] // Tu formato preferido
        }));

        res.json(resultado);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// --- RUTA CONSOLIDADA PARA REPORTES DINÁMICOS ---
app.post('/reportar', async (req, res) => {
    const { 
        id_usuario, id_modalidad, grupo, id_origen, descripcion, 
        hora_alerta, hora_llegada, hora_repliegue,
        latitud, longitud, camaras, id_tipo_vehiculo, placa_agresor 
    } = req.body;

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        // 1. Insertar en ocurrencia_registro (con el ENUM 'grupo' y los 3 TIME)
        const [resReg] = await conn.execute(
            `INSERT INTO ocurrencia_registro 
            (id_usuario, id_modalidad, grupo, id_origen, descripcion, hora_alerta, hora_llegada, hora_repliegue, latitud, longitud, fecha_registro) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [id_usuario, id_modalidad, grupo, id_origen, descripcion, hora_alerta, hora_llegada, hora_repliegue, latitud, longitud]
        );
        
        const lastId = resReg.insertId;

        // 2. Detalle si es Cámaras
        if (id_origen === 1 && camaras) {
            for (let id_cam of camaras) {
                await conn.execute("INSERT INTO detalle_camara_ocurrencia (id_ocurrencia, id_camara) VALUES (?, ?)", [lastId, id_cam]);
            }
        }

        // 3. Detalle si es Patrullaje
        if (id_origen === 2) {
            await conn.execute(
                "INSERT INTO detalle_agresores_ocurrencia (id_ocurrencia, id_tipo_vehiculo, placa_agresor) VALUES (?, ?, ?)",
                [lastId, id_tipo_vehiculo, placa_agresor]
            );
        }

        await conn.commit();
        res.json({ success: true, message: "Ocurrencia y tiempos registrados" });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ success: false, error: err.message });
    } finally {
        conn.release();
    }
});

//para ocurrencias_registro 1.
app.get('/catalogos/completos', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        // Ejecutar consultas en paralelo
        const [
            modalidades, // cat_modalidad
            usuarios,    // usuarios_sistema + persona
            lugares,     // lugar
            origenes     // origen
        ] = await Promise.all([
            connection.query('SELECT id AS value, nombre AS label FROM cat_modalidad ORDER BY nombre'),
            connection.query(`
                SELECT 
                    u.id_usuario AS value, 
                    CONCAT(p.nombres, ' ', p.apellido_paterno, ' ', COALESCE(p.apellido_materno, '')) AS label 
                FROM usuarios_sistema u 
                INNER JOIN persona p ON u.id_usuario = p.id_persona
                WHERE p.estado_laboral = 'ACTIVO'
                ORDER BY p.apellido_paterno, p.nombres
            `),
            connection.query('SELECT id_lugar AS value, nombre_lugar AS label FROM lugar ORDER BY nombre_lugar'),
            connection.query('SELECT id_origen AS value, descripcion AS label FROM origen ORDER BY descripcion')
        ]);

        res.json({ 
            usuarios: usuarios[0],
            lugares: lugares[0], 
            modalidades: modalidades[0],
            origenes: origenes[0] 
        });

    } catch (error) {
        console.error('Error catálogos:', error);
        res.status(500).json({ error: 'Error cargando catálogos' });
    } finally {
        if (connection) connection.release();
    }
});
app.post('/ocurrencias/registrar', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const { 
            id_usuario, id_lugar, id_modalidad, id_origen,
            descripcion, hora_alerta, hora_llegada, hora_repliegue,
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_evento, grupo, fotos 
        } = req.body;

        const limpiarId = (val) => {
            const num = parseInt(val);
            return isNaN(num) || num <= 0 ? null : num;
        };

        const v_usuario = limpiarId(id_usuario);
        const v_lugar = limpiarId(id_lugar);
        const v_modalidad = limpiarId(id_modalidad);
        const v_origen = limpiarId(id_origen);

        // VALIDACIONES BÁSICAS
        if (!v_usuario) throw new Error("ID de usuario requerido.");
        if (!v_lugar) throw new Error("Lugar/sector requerido.");
        if (!v_modalidad) throw new Error("Modalidad requerida.");
        if (!grupo || !['1','2','3','4'].includes(grupo)) throw new Error("Grupo inválido (1-4).");
        if (!descripcion?.trim()) throw new Error("Descripción requerida.");

        // SQL DE INSERCIÓN SIN id_tipo_ocurrencia
        const sql = `INSERT INTO ocurrencia_registro (
            descripcion, hora_alerta, hora_llegada, 
            hora_repliegue, id_lugar, id_usuario, id_modalidad, 
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_reporte, fecha_evento, estado, grupo, id_origen
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'PENDIENTE', ?, ?)`;

        const [result] = await connection.query(sql, [
            descripcion, 
            hora_alerta || null, 
            hora_llegada || null, 
            hora_repliegue || null, 
            v_lugar, 
            v_usuario, 
            v_modalidad, 
            parseFloat(latitud_gps) || null, 
            parseFloat(longitud_gps) || null, 
            nombre_punto_gps || null, 
            referencia || null, 
            unidad_encargada || 'SERENAZGO', 
            fecha_evento || null, 
            grupo, 
            v_origen
        ]);

        const id_nueva = result.insertId;

        // PROCESAMIENTO DE FOTOS
        if (fotos && Array.isArray(fotos) && fotos.length > 0) {
            const uploadPromises = fotos
                .filter(f => f && f.base64_data)
                .map(f => cloudinary.uploader.upload(f.base64_data, { 
                    folder: 'serenazgo/ocurrencias', 
                    resource_type: 'auto'
                }));
            
            const uploadResults = await Promise.all(uploadPromises);
            const photoValues = uploadResults.map(r => [id_nueva, r.secure_url, r.public_id]);
            
            await connection.query(
                'INSERT INTO foto_ocurrencia_registro (id_ocurrencia, url_imagen, public_id) VALUES ?',
                [photoValues]
            );
        }

        await connection.commit();
        res.status(201).json({ 
            success: true, 
            message: "Ocurrencia registrada exitosamente", 
            id: id_nueva 
        });

    } catch (error) {
        if (connection) await connection.rollback();
        console.error("ERROR EN REGISTRO:", error);
        res.status(400).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});

// para camara verificado
app.get('/catalogos/completo/cam', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [
            modalidadesRes, 
            usuariosRes,    
            lugaresRes,     
            origenesRes, 
            camarasRes   
        ] = await Promise.all([
            // Modalidades
            connection.query('SELECT id AS value, nombre AS label FROM cat_modalidad ORDER BY nombre'),
            
            // Usuarios (Concatenados)
            connection.query(`
                SELECT 
                    u.id_usuario AS value, 
                    CONCAT(p.apellido_paterno, ' ', p.apellido_materno, ', ', p.nombres) AS label 
                FROM usuarios_sistema u 
                INNER JOIN persona p ON u.id_usuario = p.id_persona
                WHERE p.estado_laboral = 'ACTIVO'
                ORDER BY p.apellido_paterno, p.nombres
            `),

            // Lugares
            connection.query('SELECT id_lugar AS value, nombre_lugar AS label FROM lugar ORDER BY nombre_lugar'),

            // Orígenes
            connection.query('SELECT id_origen AS value, descripcion AS label FROM origen ORDER BY descripcion'),

            // CÁMARAS: Aquí incluimos el código en el label usando CONCAT
            connection.query(`
                SELECT 
                    id_camara AS value, 
                    CONCAT(codigo_camara, ' - ', nombre_camara) AS label 
                FROM camara 
                ORDER BY codigo_camara ASC
            `)
        ]);

        res.json({ 
            usuarios: usuariosRes[0],
            lugares: lugaresRes[0], 
            modalidades: modalidadesRes[0],
            origenes: origenesRes[0],
            camara: camarasRes[0] 
        });

    } catch (error) {
        console.error('Error catálogos:', error);
        res.status(500).json({ error: 'Error cargando catálogos' });
    } finally {
        if (connection) connection.release();
    }
});
app.post('/ocurrencias/registrar/cam', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const { 
            id_usuario, id_lugar, id_modalidad, id_origen, id_camara,
            descripcion, hora_alerta, hora_llegada, hora_repliegue,
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_evento, grupo, fotos 
        } = req.body;

        // 1. INSERTAR OCURRENCIA (Incluyendo GPS para evitar el error de default value)
        const sqlOcurrencia = `INSERT INTO ocurrencia_registro (
            descripcion, hora_alerta, hora_llegada, hora_repliegue, 
            id_lugar, id_usuario, id_modalidad, id_origen,
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_reporte, fecha_evento, estado, grupo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'PENDIENTE', ?)`;

        const [resOcurrencia] = await connection.query(sqlOcurrencia, [
            descripcion, 
            hora_alerta || null, 
            hora_llegada || null, 
            hora_repliegue || null, 
            id_lugar, 
            id_usuario, 
            id_modalidad, 
            id_origen, 
            latitud_gps || 0,        // GPS captado del celular
            longitud_gps || 0,       // GPS captado del celular
            nombre_punto_gps || '', 
            referencia || '', 
            unidad_encargada || 'SERENAZGO', 
            fecha_evento, 
            grupo
        ]);

        const id_nueva_ocurrencia = resOcurrencia.insertId;

        // 2. INSERTAR EN detalle_camara (Vínculo con la tabla camara)
     if (id_camara) {
    // 1. Convertimos el string '7,9,20' en un array real [7, 9, 20]
    const idsCamaras = id_camara.split(',').map(id => id.trim());

    // 2. Definimos la consulta
    const sqlDetalleCamara = 'INSERT INTO detalle_camara_ocurrencia (id_ocurrencia, id_camara) VALUES (?, ?)';

    // 3. Ejecutamos un insert por cada cámara usando un bucle for...of
    // Esto asegura que cada cámara se guarde como un número individual
    for (const id of idsCamaras) {
        if (id) { // Verificamos que el ID no esté vacío
            await connection.query(sqlDetalleCamara, [id_nueva_ocurrencia, id]);
        }
    }
}

        // 3. PROCESAR FOTOS (Subida a Cloudinary)
        if (fotos && Array.isArray(fotos) && fotos.length > 0) {
            const uploadPromises = fotos
                .filter(f => f && f.base64_data)
                .map(f => cloudinary.uploader.upload(f.base64_data, { 
                    folder: 'serenazgo/ocurrencias',
                    resource_type: 'auto'
                }));
            
            const uploadResults = await Promise.all(uploadPromises);

            const photoValues = uploadResults.map(r => [
                id_nueva_ocurrencia, 
                r.secure_url, 
                r.public_id
            ]);
            
            await connection.query(
                'INSERT INTO foto_ocurrencia_registro (id_ocurrencia, url_imagen, public_id) VALUES ?',
                [photoValues]
            );
        }

        await connection.commit();
        res.status(201).json({ success: true, id: id_nueva_ocurrencia });

    } catch (error) {
        if (connection) await connection.rollback();
        console.error("ERROR:", error);
        res.status(400).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});
// para camara verificado 1
app.get('/catalogos/completo/camn', async (req, res) => {
    let connection;
    const tipoLugar = req.query.tipoLugar || 5;
    try {
        connection = await db.getConnection();

        const [
            modalidadesRes, 
            usuariosRes,    
            lugaresRes,     
            origenesRes, 
            camarasRes,
            tiposPatrullajeRes,    // Resultado para tipo_patrullaje
            modPatrullajeRes       // Resultado para modalidad_patrullaje
        ] = await Promise.all([
            // 1. Modalidades de Ocurrencia
            connection.query('SELECT id AS value, nombre AS label FROM cat_modalidad ORDER BY nombre'),
            
            // 2. Usuarios
            connection.query(`
                SELECT 
                    u.id_usuario AS value, 
                    CONCAT(p.apellido_paterno, ' ', p.apellido_materno, ', ', p.nombres) AS label 
                FROM usuarios_sistema u 
                INNER JOIN persona p ON u.id_usuario = p.id_persona
                WHERE p.estado_laboral = 'ACTIVO'
                ORDER BY p.apellido_paterno, p.nombres
            `),

            // 3. Lugares
    connection.query(`
                SELECT 
                    l.id_lugar AS value, 
                    CONCAT(tv.abreviatura, ' ', v.nombre_via, ' CDRA. ', c.numero_cuadra) AS label 
                FROM lugar l
                INNER JOIN cuadra c ON l.id_cuadra = c.id_cuadra
                INNER JOIN via v ON l.id_via = v.id_via
                INNER JOIN tipo_via tv ON v.id_tipo_via = tv.id_tipo_via
                WHERE l.id_tipo_lugar = ?
                ORDER BY v.nombre_via ASC, c.numero_cuadra ASC
            `, [tipoLugar]),
            // 4. Orígenes
            connection.query('SELECT id_origen AS value, descripcion AS label FROM origen ORDER BY descripcion'),

            // 5. Cámaras
            connection.query(`
                SELECT 
                    id_camara AS value, 
                    CONCAT(codigo_camara, ' - ', nombre_camara) AS label 
                FROM camara 
                ORDER BY codigo_camara ASC
            `),

            // 6. NUEVO: Catálogo de Tipo de Patrullaje
            connection.query('SELECT id_tipop AS value, nombre AS label FROM tipo_patrullaje ORDER BY nombre'),

            // 7. NUEVO: Catálogo de Modalidad de Patrullaje
            connection.query('SELECT id_modalidadp AS value, nombre AS label FROM modalidad_patrullaje ORDER BY nombre')
        ]);

        // Enviamos todo consolidado al frontend
        res.json({ 
            usuarios: usuariosRes[0],
            lugares: lugaresRes[0], 
            modalidades: modalidadesRes[0],
            origenes: origenesRes[0],
            camara: camarasRes[0],
            tipos_patrullaje: tiposPatrullajeRes[0],
            modalidades_patrullaje: modPatrullajeRes[0]
        });

    } catch (error) {
        console.error('Error al cargar catálogos:', error);
        res.status(500).json({ error: 'Error cargando catálogos' });
    } finally {
        if (connection) connection.release();
    }
});

app.post('/ocurrencias/registrar/camn', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const { 
            id_usuario, id_lugar, id_modalidad, id_origen, id_camara,
            id_tipop, id_modalidadp, // NUEVOS CAMPOS
            descripcion, hora_alerta, hora_llegada, hora_repliegue,
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_evento, grupo, fotos 
        } = req.body;

        // 1. INSERTAR OCURRENCIA (Actualizado con los nuevos campos de patrullaje)
        const sqlOcurrencia = `INSERT INTO ocurrencia_registro (
            descripcion, hora_alerta, hora_llegada, hora_repliegue, 
            id_lugar, id_usuario, id_modalidad, id_origen,
            id_tipop, id_modalidadp, 
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_reporte, fecha_evento, estado, grupo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'PENDIENTE', ?)`;

        const [resOcurrencia] = await connection.query(sqlOcurrencia, [
            descripcion, 
            hora_alerta || null, 
            hora_llegada || null, 
            hora_repliegue || null, 
            id_lugar, 
            id_usuario, 
            id_modalidad, 
            id_origen,
            id_tipop || null,      // NUEVO
            id_modalidadp || null, // NUEVO
            latitud_gps || 0,
            longitud_gps || 0,
            nombre_punto_gps || '', 
            referencia || '', 
            unidad_encargada || 'SERENAZGO', 
            fecha_evento, 
            grupo
        ]);

        const id_nueva_ocurrencia = resOcurrencia.insertId;

        // 2. INSERTAR EN detalle_camara_ocurrencia
        if (id_camara) {
            // Si el frontend envía un string como '7,9,20'
            const idsCamaras = typeof id_camara === 'string' 
                ? id_camara.split(',').map(id => id.trim()) 
                : [id_camara];

            const sqlDetalleCamara = 'INSERT INTO detalle_camara_ocurrencia (id_ocurrencia, id_camara) VALUES (?, ?)';

            for (const id of idsCamaras) {
                if (id) {
                    await connection.query(sqlDetalleCamara, [id_nueva_ocurrencia, id]);
                }
            }
        }

        // 3. PROCESAR FOTOS (Cloudinary)
        if (fotos && Array.isArray(fotos) && fotos.length > 0) {
            const uploadPromises = fotos
                .filter(f => f && f.base64_data)
                .map(f => cloudinary.uploader.upload(f.base64_data, { 
                    folder: 'serenazgo/ocurrencias',
                    resource_type: 'auto'
                }));
            
            const uploadResults = await Promise.all(uploadPromises);

            const photoValues = uploadResults.map(r => [
                id_nueva_ocurrencia, 
                r.secure_url, 
                r.public_id
            ]);
            
            await connection.query(
                'INSERT INTO foto_ocurrencia_registro (id_ocurrencia, url_imagen, public_id) VALUES ?',
                [photoValues]
            );
        }

        await connection.commit();
        res.status(201).json({ success: true, id: id_nueva_ocurrencia });

    } catch (error) {
        if (connection) await connection.rollback();
        console.error("ERROR REGISTRO:", error);
        res.status(400).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});


//cascada
// --- 1. ENDPOINT CONSOLIDADO (Ajustado para no cargar todos los lugares de golpe) ---
app.get('/catalogos/completo/camna', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [
            modalidadesRes,
            usuariosRes,
            origenesRes,
            camarasRes,
            tiposPatrullajeRes,
            modPatrullajeRes,
            tiposViaRes // Agregamos tipos de vía aquí para la carga inicial
        ] = await Promise.all([
            connection.query('SELECT id AS value, nombre AS label FROM cat_modalidad ORDER BY nombre'),
            connection.query(`
                SELECT u.id_usuario AS value, 
                CONCAT(p.apellido_paterno, ' ', p.apellido_materno, ', ', p.nombres) AS label 
                FROM usuarios_sistema u 
                INNER JOIN persona p ON u.id_usuario = p.id_persona
                WHERE p.estado_laboral = 'ACTIVO'
                ORDER BY p.apellido_paterno, p.nombres
            `),
            connection.query('SELECT id_origen AS value, descripcion AS label FROM origen ORDER BY descripcion'),
            connection.query('SELECT id_camara AS value, CONCAT(codigo_camara, " - ", nombre_camara) AS label FROM camara ORDER BY codigo_camara ASC'),
            connection.query('SELECT id_tipop AS value, nombre AS label FROM tipo_patrullaje ORDER BY nombre'),
            connection.query('SELECT id_modalidadp AS value, nombre AS label FROM modalidad_patrullaje ORDER BY nombre'),
            connection.query('SELECT id_tipo_via AS value, abreviatura AS label FROM tipo_via ORDER BY abreviatura ASC')
        ]);

        res.json({
            usuarios: usuariosRes[0],
            modalidades: modalidadesRes[0],
            origenes: origenesRes[0],
            camara: camarasRes[0],
            tipos_patrullaje: tiposPatrullajeRes[0],
            modalidades_patrullaje: modPatrullajeRes[0],
            tipos_via: tiposViaRes[0] // Esto cargará el primer Picker
        });

    } catch (error) {
        console.error('Error al cargar catálogos:', error);
        res.status(500).json({ error: 'Error cargando catálogos' });
    } finally {
        if (connection) connection.release();
    }
});

// --- 2. ENDPOINT PARA VÍAS (Depende de Tipo de Vía) ---
app.get('/catalogos/vias/:idTipoVia', async (req, res) => {
    let connection;
    try {
        const { idTipoVia } = req.params;
        connection = await db.getConnection();
        const [rows] = await connection.query(
            'SELECT id_via AS value, nombre_via AS label FROM via WHERE id_tipo_via = ? ORDER BY nombre_via ASC',
            [idTipoVia]
        );
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    } finally {
        if (connection) connection.release();
    }
});

// --- 3. ENDPOINT PARA CUADRAS (Depende de Vía - Retorna id_lugar) ---
app.get('/catalogos/cuadras/:idVia', async (req, res) => {
    let connection;
    try {
        const { idVia } = req.params;
        const tipoLugar = req.query.tipoLugar || 5;
        connection = await db.getConnection();
        const [rows] = await connection.query(`
            SELECT 
                l.id_lugar AS value, 
                CONCAT('CDRA. ', c.numero_cuadra) AS label 
            FROM lugar l
            INNER JOIN cuadra c ON l.id_cuadra = c.id_cuadra
            WHERE l.id_via = ? AND l.id_tipo_lugar = ?
            ORDER BY CAST(c.numero_cuadra AS UNSIGNED) ASC`,
            [idVia, tipoLugar]
        );
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    } finally {
        if (connection) connection.release();
    }
});
// --- FIN DE CASCADA ---
app.post('/ocurrencias/registrar/modalidad', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const { 
            id_usuario, id_lugar, id_modalidad, id_origen,
            id_tipop, id_modalidadp, 
            descripcion, hora_alerta, hora_llegada, hora_repliegue,
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_evento, grupo, fotos 
        } = req.body;

        // 1. INSERTAR OCURRENCIA
        const sqlOcurrencia = `INSERT INTO ocurrencia_registro (
            descripcion, hora_alerta, hora_llegada, hora_repliegue, 
            id_lugar, id_usuario, id_modalidad, id_origen,
            id_tipop, id_modalidadp, 
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_reporte, fecha_evento, estado, grupo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'PENDIENTE', ?)`;

        const [resOcurrencia] = await connection.query(sqlOcurrencia, [
            descripcion, 
            hora_alerta || null, 
            hora_llegada || null, 
            hora_repliegue || null, 
            id_lugar, 
            id_usuario, 
            id_modalidad, 
            id_origen, // Enviará 1 por defecto desde el front
            id_tipop || 1,      
            id_modalidadp || 1, 
            latitud_gps || 0,
            longitud_gps || 0,
            nombre_punto_gps || '', 
            referencia || '', 
            unidad_encargada || 'SERENAZGO', 
            fecha_evento, 
            grupo
        ]);

        const id_nueva_ocurrencia = resOcurrencia.insertId;

        // 2. PROCESAR FOTOS (Cloudinary)
        // Se mantiene igual para que las evidencias se guarden correctamente
        if (fotos && Array.isArray(fotos) && fotos.length > 0) {
            const uploadPromises = fotos
                .filter(f => f && f.base64_data)
                .map(f => cloudinary.uploader.upload(f.base64_data, { 
                    folder: 'serenazgo/ocurrencias',
                    resource_type: 'auto'
                }));
            
            const uploadResults = await Promise.all(uploadPromises);

            const photoValues = uploadResults.map(r => [
                id_nueva_ocurrencia, 
                r.secure_url, 
                r.public_id
            ]);
            
            await connection.query(
                'INSERT INTO foto_ocurrencia_registro (id_ocurrencia, url_imagen, public_id) VALUES ?',
                [photoValues]
            );
        }

        await connection.commit();
        res.status(201).json({ success: true, id: id_nueva_ocurrencia });

    } catch (error) {
        if (connection) await connection.rollback();
        console.error("ERROR REGISTRO:", error);
        res.status(400).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});

//obtener vehiculos
// 1. Obtener tipos de vehículo (para el primer dropdown)
app.get('/catalogos/tipos-vehiculo', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT id_tipo_vehiculo as value, descripcion as label FROM tipo_vehiculo');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// Obtener vehículos por tipo que estén ACTIVOS
app.get('/catalogos/vehiculos-por-tipo/:idTipo', async (req, res) => {
    try {
        const { idTipo } = req.params;
        const query = `
            SELECT 
                id_unidad as value, 
                placa as label 
            FROM sipcop_flota_municipal 
            WHERE id_tipo_vehiculo = ? 
            AND estado = 1
        `;
        
        const [rows] = await db.query(query, [idTipo]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Error al obtener la flota activa" });
    }
});

app.post('/ocurrencias/registrar/veh', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const { 
            id_usuario, id_lugar, id_modalidad, id_origen,
            id_tipop, id_modalidadp, vehiculos_detalle,
            descripcion, hora_alerta, hora_llegada, hora_repliegue,
            latitud_gps, longitud_gps, referencia, 
            unidad_encargada, fecha_evento, grupo
        } = req.body;

        const sqlOcurrencia = `INSERT INTO ocurrencia_registro (
            descripcion, hora_alerta, hora_llegada, hora_repliegue, 
            id_lugar, id_usuario, id_modalidad, id_origen,
            id_tipop, id_modalidadp, 
            latitud_gps, longitud_gps, referencia, 
            unidad_encargada, fecha_reporte, fecha_evento, estado, grupo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'PENDIENTE', ?)`;

        const [resOcurrencia] = await connection.query(sqlOcurrencia, [
            descripcion, hora_alerta || null, hora_llegada || null, hora_repliegue || null, 
            id_lugar, id_usuario, id_modalidad, id_origen || 3, id_tipop || 1, id_modalidadp || 1, 
            latitud_gps || 0, longitud_gps || 0, referencia || '', 
            unidad_encargada || 'SERENAZGO', fecha_evento, grupo
        ]);

        const id_nueva_ocu = resOcurrencia.insertId;

        if (id_tipop === 3 && vehiculos_detalle?.length > 0) {
            const values = vehiculos_detalle.map(v => [id_nueva_ocu, v.id_tipo_vehiculo, v.id_unidad]);
            await connection.query(`INSERT INTO ocurrencia_vehiculo_detalle (id_ocurrencia, id_tipo_vehiculo, id_unidad) VALUES ?`, [values]);
        }

        await connection.commit();
        res.status(201).json({ success: true, id: id_nueva_ocu });
    } catch (error) {
        if (connection) await connection.rollback();
        res.status(400).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});
app.get('/catalogos/pnp-activos', async (req, res) => {
    try {
        const [rows] = await db.query("SELECT id_pnp as value, CONCAT(grado, ' ', nombres, ' ', apellidos) as label FROM cat_pnp WHERE estado = 1");
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.post('/ocurrencias/registrar/vehi', async (req, res) => {
    let connection;
    let uploadedPublicIds = []; // Para limpieza si algo falla

    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const { 
            id_usuario, id_lugar, id_modalidad, id_origen,
            id_tipop, id_modalidadp, vehiculos_detalle,
            descripcion, hora_alerta, hora_llegada, hora_repliegue,
            latitud_gps, longitud_gps, referencia, 
            unidad_encargada, fecha_evento, grupo, fotos
        } = req.body;

        // 1. INSERTAR CABECERA
        const sqlOcurrencia = `INSERT INTO ocurrencia_registro (
            descripcion, hora_alerta, hora_llegada, hora_repliegue, 
            id_lugar, id_usuario, id_modalidad, id_origen,
            id_tipop, id_modalidadp, 
            latitud_gps, longitud_gps, referencia, 
            unidad_encargada, fecha_reporte, fecha_evento, estado, grupo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'PENDIENTE', ?)`;

        const [resOcurrencia] = await connection.query(sqlOcurrencia, [
            descripcion, 
            hora_alerta || null, 
            hora_llegada || null, 
            hora_repliegue || null, 
            id_lugar, 
            id_usuario, 
            id_modalidad || 126, 
            id_origen || 3, 
            id_tipop || 1, 
            id_modalidadp || 1, 
            latitud_gps || '0', 
            longitud_gps || '0', 
            referencia || '', 
            unidad_encargada || 'SERENAZGO', 
            fecha_evento, 
            grupo || '1'
        ]);

        const id_nueva_ocu = resOcurrencia.insertId;

        // 2. INSERTAR DETALLE DE VEHÍCULOS
        if (vehiculos_detalle && Array.isArray(vehiculos_detalle) && vehiculos_detalle.length > 0) {
            const values = vehiculos_detalle.map(v => [
                id_nueva_ocu, 
                v.id_tipo_vehiculo, 
                v.id_unidad, 
                v.tipo_asignacion || 'MUNICIPAL', 
                v.id_pnp || null
            ]);

            const sqlDetalle = `INSERT INTO ocurrencia_vehiculo_detalle 
                (id_ocurrencia, id_tipo_vehiculo, id_unidad, tipo_asignacion, id_pnp) 
                VALUES ?`;

            await connection.query(sqlDetalle, [values]);
        }

        // 3. PROCESAR FOTOS CON CLOUDINARY
        if (fotos && Array.isArray(fotos) && fotos.length > 0) {
            const uploadPromises = fotos
                .filter(f => f && f.base64_data)
                .map(f => {
                    // Asegurar prefijo base64 para Cloudinary
                    const fileStr = f.base64_data.startsWith('data:') 
                        ? f.base64_data 
                        : `data:image/jpeg;base64,${f.base64_data}`;

                    return cloudinary.uploader.upload(fileStr, { 
                        folder: 'serenazgo/ocurrencias',
                        resource_type: 'auto'
                    });
                });
            
            const uploadResults = await Promise.all(uploadPromises);
            
            // Guardamos IDs por si hay que borrar en el catch
            uploadedPublicIds = uploadResults.map(r => r.public_id);

            const photoValues = uploadResults.map(r => [
                id_nueva_ocu, 
                r.secure_url, 
                r.public_id
            ]);
            
            const sqlFotos = `INSERT INTO foto_ocurrencia_registro (id_ocurrencia, url_imagen, public_id) VALUES ?`;
            await connection.query(sqlFotos, [photoValues]);
        }

        // 4. COMMIT FINAL
        await connection.commit();
        res.status(201).json({ success: true, id: id_nueva_ocu });

    } catch (error) {
        // ROLLBACK DE BASE DE DATOS
        if (connection) await connection.rollback();

        // LIMPIEZA DE CLOUDINARY (Opcional pero recomendado)
        // Si la DB falló, borramos las fotos recién subidas para no dejar basura
        if (uploadedPublicIds.length > 0) {
            await cloudinary.api.delete_resources(uploadedPublicIds);
        }

        console.error("ERROR EN REGISTRO:", error);
        res.status(400).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});
app.post('/ocurrencias/registrar/modvehi', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const { 
            id_usuario, id_lugar, id_modalidad, id_origen,
            id_tipop, id_modalidadp, 
            descripcion, hora_alerta, hora_llegada, hora_repliegue,
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_evento, grupo, fotos,
            vehiculos_detalle // <--- Agregado para recibir el detalle
        } = req.body;

        // 1. INSERTAR OCURRENCIA
        const sqlOcurrencia = `INSERT INTO ocurrencia_registro (
            descripcion, hora_alerta, hora_llegada, hora_repliegue, 
            id_lugar, id_usuario, id_modalidad, id_origen,
            id_tipop, id_modalidadp, 
            latitud_gps, longitud_gps, nombre_punto_gps, referencia, 
            unidad_encargada, fecha_reporte, fecha_evento, estado, grupo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'PENDIENTE', ?)`;

        const [resOcurrencia] = await connection.query(sqlOcurrencia, [
            descripcion, 
            hora_alerta || null, 
            hora_llegada || null, 
            hora_repliegue || null, 
            id_lugar, 
            id_usuario, 
            id_modalidad, 
            id_origen, 
            id_tipop || 1,      
            id_modalidadp || 1, 
            latitud_gps || 0,
            longitud_gps || 0,
            nombre_punto_gps || '', 
            referencia || '', 
            unidad_encargada || 'SERENAZGO', 
            fecha_evento, 
            grupo
        ]);

        const id_nueva_ocurrencia = resOcurrencia.insertId;

        // 2. INSERTAR DETALLE DE VEHÍCULOS (NUEVA SECCIÓN)
        if (vehiculos_detalle && Array.isArray(vehiculos_detalle) && vehiculos_detalle.length > 0) {
            const values = vehiculos_detalle.map(v => [
                id_nueva_ocurrencia, 
                v.id_tipo_vehiculo, 
                v.id_unidad, 
                v.tipo_asignacion || 'MUNICIPAL', 
                v.id_pnp || null
            ]);

            const sqlDetalle = `INSERT INTO ocurrencia_vehiculo_detalle 
                (id_ocurrencia, id_tipo_vehiculo, id_unidad, tipo_asignacion, id_pnp) 
                VALUES ?`;

            await connection.query(sqlDetalle, [values]);
        }

        // 3. PROCESAR FOTOS (Cloudinary)
        if (fotos && Array.isArray(fotos) && fotos.length > 0) {
            const uploadPromises = fotos
                .filter(f => f && f.base64_data)
                .map(f => cloudinary.uploader.upload(f.base64_data, { 
                    folder: 'serenazgo/ocurrencias',
                    resource_type: 'auto'
                }));
            
            const uploadResults = await Promise.all(uploadPromises);

            const photoValues = uploadResults.map(r => [
                id_nueva_ocurrencia, 
                r.secure_url, 
                r.public_id
            ]);
            
            await connection.query(
                'INSERT INTO foto_ocurrencia_registro (id_ocurrencia, url_imagen, public_id) VALUES ?',
                [photoValues]
            );
        }

        await connection.commit();
        res.status(201).json({ success: true, id: id_nueva_ocurrencia });

    } catch (error) {
        if (connection) await connection.rollback();
        console.error("ERROR REGISTRO:", error);
        res.status(400).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});
// GET: Listar todas las ocurrencias con sus nombres de catálogo
app.get('/ocurrencias/listar/modvehi', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        // Parámetros de paginación
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const offset = (page - 1) * limit;

        // Tu consulta SQL exacta
        const sql = `
           SELECT 
    o.id_ocurrencia,
    o.fecha_reporte,
     o.codigo_seguimiento,
    o.fecha_evento,
      o.hora_llegada,
    o.descripcion,
    o.unidad_encargada,
     o.referencia,
    -- Información de la Persona (Usuario que registra)
    p.documento_numero AS persona_dni,
    CONCAT(p.apellido_paterno, ' ', p.apellido_materno, ', ', p.nombres) AS persona_nombre_completo,

    -- Nombres de catálogos
    m.nombre AS modalidad_nombre,
    v.nombre_via AS via_nombre,
    c.numero_cuadra AS cuadra,
    tp.nombre AS tipo_patrullaje_nombre,
    mp.nombre AS mod_patrullaje_nombre,

    -- Ubicación formateada
    l.id_lugar AS value, 
    CONCAT(tv.abreviatura, ' ', v.nombre_via, ' CDRA. ', c.numero_cuadra) AS label,
    
    -- Subconsultas para fotos
    (SELECT COUNT(*) FROM foto_ocurrencia_registro f 
     WHERE f.id_ocurrencia = o.id_ocurrencia) as total_fotos,
    
    (SELECT url_imagen FROM foto_ocurrencia_registro f 
     WHERE f.id_ocurrencia = o.id_ocurrencia LIMIT 1) as foto_principal

FROM ocurrencia_registro o
-- Relación con Persona
LEFT JOIN usuarios_sistema us ON o.id_usuario = us.id_usuario -- Ajustar según el campo de relación en o
LEFT JOIN persona p ON us.id_persona = p.id_persona
-- Otros Joins existentes
LEFT JOIN cat_modalidad m ON o.id_modalidad = m.id
LEFT JOIN lugar l ON o.id_lugar = l.id_lugar
LEFT JOIN via v ON l.id_via = v.id_via
LEFT JOIN cuadra c ON l.id_cuadra = c.id_cuadra
LEFT JOIN tipo_via tv ON v.id_tipo_via = tv.id_tipo_via
LEFT JOIN tipo_patrullaje tp ON o.id_tipop = tp.id_tipop
LEFT JOIN modalidad_patrullaje mp ON o.id_modalidadp = mp.id_modalidadp

ORDER BY o.fecha_reporte DESC;
        `;

        const [rows] = await connection.query(sql, [limit, offset]);

        // Formateo para el componente TSX
        const respuesta = rows.map(item => ({
            ...item,
            fecha_evento: item.fecha_evento ? new Date(item.fecha_evento).toISOString().split('T')[0] : 'S/F',
            tiene_fotos: item.total_fotos > 0,
            // Convertimos la foto única en un array para que el componente no falle
            fotos: item.foto_principal ? [item.foto_principal] : []
        }));

        res.json(respuesta);

    } catch (error) {
        console.error("ERROR:", error);
        res.status(500).json({ success: false, error: error.message });
    } finally {
        if (connection) connection.release();
    }
});

app.get('/catalogos/completo/unificado', async (req, res) => {
    let connection;
    // Extraemos el tipo de vía si viene en el query (para la carga de lugares)
    const { tipoLugar } = req.query;

    try {
        connection = await db.getConnection();

        // Definimos las consultas base que siempre se ejecutan
        const queries = [
            connection.query('SELECT id AS value, nombre AS label FROM cat_modalidad ORDER BY nombre'),
            connection.query(`
                SELECT u.id_usuario AS value, 
                CONCAT(p.apellido_paterno, ' ', p.apellido_materno, ', ', p.nombres) AS label 
                FROM usuarios_sistema u 
                INNER JOIN persona p ON u.id_usuario = p.id_persona
                WHERE p.estado_laboral = 'ACTIVO'
                ORDER BY p.apellido_paterno, p.nombres
            `),
            connection.query('SELECT id_origen AS value, descripcion AS label FROM origen ORDER BY descripcion'),
            connection.query('SELECT id_camara AS value, CONCAT(codigo_camara, " - ", nombre_camara) AS label FROM camara ORDER BY codigo_camara ASC'),
            connection.query('SELECT id_tipop AS value, nombre AS label FROM tipo_patrullaje ORDER BY nombre'),
            connection.query('SELECT id_modalidadp AS value, nombre AS label FROM modalidad_patrullaje ORDER BY nombre'),
            connection.query('SELECT id_tipo_via AS value, abreviatura AS label FROM tipo_via ORDER BY abreviatura ASC')
        ];

        // Si tipoLugar está presente, añadimos la consulta de lugares al array de promesas
        if (tipoLugar) {
            queries.push(
                connection.query(`
                    SELECT 
                        l.id_lugar AS value, 
                        CONCAT(tv.abreviatura, ' ', v.nombre_via, ' CDRA. ', c.numero_cuadra) AS label 
                    FROM lugar l
                    INNER JOIN cuadra c ON l.id_cuadra = c.id_cuadra
                    INNER JOIN via v ON l.id_via = v.id_via
                    INNER JOIN tipo_via tv ON v.id_tipo_via = tv.id_tipo_via
                    WHERE l.id_tipo_lugar = ?
                    ORDER BY v.nombre_via ASC, c.numero_cuadra ASC
                `, [tipoLugar])
            );
        }

        const results = await Promise.all(queries);

        // Mapeo de resultados
        const response = {
            modalidades: results[0][0],
            usuarios: results[1][0],
            origenes: results[2][0],
            camaras: results[3][0],
            tipos_patrullaje: results[4][0],
            modalidades_patrullaje: results[5][0],
            tipos_via: results[6][0]
        };

        // Si se consultaron lugares, se agregan al objeto final
        if (tipoLugar) {
            response.lugares = results[7][0];
        }

        res.json(response);

    } catch (error) {
        console.error('Error al cargar catálogos consolidados:', error);
        res.status(500).json({ error: 'Error interno al cargar catálogos' });
    } finally {
        if (connection) connection.release();
    }
});
const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Servidor Corriendo en http://172.20.10:3000${PORT}`);
});